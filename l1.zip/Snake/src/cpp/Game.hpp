#pragma once

#include "AppleSpawner.hpp"
#include "IClock.hpp"
#include "Snake.hpp"

template <uint8_t GridSize>
class Game
{
public:
    static constexpr uint8_t MaxTails{GridSize - 1};//63
    static constexpr uint8_t MaxApples{MaxTails - 1};//62

    Game(const IClock& clock);

    void Update();

    void OnEvent(Direction direction);

    inline const Snake<MaxTails>& GetSnake() const;
    inline const AppleSpawner<MaxApples, MaxTails>& GetAppleSpawner() const;

private:
    const uint32_t m_turn_delay{1'000};//задержка для поворота
    uint32_t m_last_rotate_tick{};

    Snake<MaxTails> m_snake;
    AppleSpawner<MaxApples, MaxTails> m_apple_spawner;

    volatile bool m_is_rotate_right_pressed{};//для прерывания
    volatile bool m_is_rotate_left_pressed{};

    const IClock& m_clock;

    void HandleInput();//обрабботка ввода

    void HandleButton(volatile bool& event_flag, Direction direction);//проверка-проиграл ли
    void HandleAppleCollision();//кушание

    bool IsOutsideGrid(Vector2i pos);//вышли за сетку
    bool IsGameOver();
    void RestartGame();
};

#include "Game.inl"