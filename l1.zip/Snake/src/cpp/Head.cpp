#include "Head.hpp"

void Head::ChangeDirection(Direction direction) //поворот
{
    switch (direction)
    {
        case Direction::Left:
        {
            if (m_direction == kUp)// если смотрели вверх то идем на лево
                m_direction = kLeft;
            else if (m_direction == kLeft)// если смотрели влево то идем вниз
                m_direction = kDown;
            else if (m_direction == kDown)// если смотрели вниз то идем на право
                m_direction = kRight;
            else
                m_direction = kUp;// если смотрели вправо то идем на вверх

            break;
        }
        case Direction::Right:
        {
            if (m_direction == kUp)
                m_direction = kRight;
            else if (m_direction == kRight)
                m_direction = kDown;
            else if (m_direction == kDown)
                m_direction = kLeft;
            else
                m_direction = kUp;

            break;
        }
        default:
        {
            // "You DUMB!"
            // std::abort();
        }
    }
}

void Head::MoveForward()
{
    m_position += m_direction;
}
